# ssmLab
1. Receptionist Functions registerPatient(patientDetails)  assignDoctorToPatient(patientId, doctorId)  updatePatientInfo(patientId, updatedDetails)  searchPatient(query)  viewAppointments()  scheduleAppointment(patientId, doctorId, time)  🩺 2. Doctor Functions viewPatientDetails(patientId)  recordDiagnosis(patientId, 
